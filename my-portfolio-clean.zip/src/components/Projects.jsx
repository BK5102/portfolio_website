export default function Projects() {
  return <section className="p-8">Projects will go here.</section>;
}