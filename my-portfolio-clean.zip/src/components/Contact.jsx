export default function Contact() {
  return <section className="p-8">Contact me at: email@example.com</section>;
}