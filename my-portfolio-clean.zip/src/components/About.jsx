export default function About() {
  return <section className="p-8 text-gray-700">I’m a developer passionate about building impactful software.</section>;
}