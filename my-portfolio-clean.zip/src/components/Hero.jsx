export default function Hero() {
  return <section className="text-center py-16 text-4xl font-bold text-blue-600">Welcome to my portfolio!</section>;
}